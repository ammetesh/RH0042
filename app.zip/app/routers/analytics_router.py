﻿from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.services.executive_dashboard_service import get_executive_dashboard

router = APIRouter(
    prefix="/analytics",
    tags=["Analytics"]
)

@router.get(
    "/executive-dashboard",
    summary="Executive Dashboard",
    description="Returns all analytics required for the frontend dashboard in a single response."
)
def executive_dashboard(db: Session = Depends(get_db)):
    return get_executive_dashboard(db)
